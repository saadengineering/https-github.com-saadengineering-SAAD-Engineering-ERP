const API="../api";
const CLOUD_NAME="hzjcimv7";
const UPLOAD_PRESET="saadengineering";
async function uploadToCloudinary(file){const fd=new FormData();fd.append("file",file);fd.append("upload_preset",UPLOAD_PRESET);const r=await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`,{method:"POST",body:fd});if(!r.ok)throw new Error("Cloudinary upload failed");const j=await r.json();return j.secure_url}
const $=id=>document.getElementById(id);
function login(){
 const id=$("adminId").value.trim(), pass=$("adminPass").value;
 if(id==="admin" && pass==="saad123"){
   sessionStorage.saadAdmin="1";
   $("loginScreen").hidden=true;
   $("adminApp").hidden=false;
   // Login must work even if the API/D1 has not been bound yet.
   renderAll(true);
 }else{
   alert("Admin ID or Password is incorrect.");
 }
}
function showApp(){
 if(sessionStorage.saadAdmin==="1"){
   $("loginScreen").hidden=true;
   $("adminApp").hidden=false;
   renderAll(true);
 }
}
function logout(){sessionStorage.removeItem("saadAdmin");location.reload()}
let selectedImages=[];
$("pimages").addEventListener("change",async e=>{selectedImages=[];try{for(const file of [...e.target.files]){const url=await uploadToCloudinary(file);selectedImages.push({data:url,name:file.name});renderPreview()}}catch(err){alert("Cloudinary upload failed. Check Cloud Name and UNSIGNED Upload Preset.")}});
function renderPreview(){$("preview").innerHTML=selectedImages.map(x=>`<img src="${x.data}">`).join("")}
async function readApiError(r, fallback){
  const raw = await r.text();
  let detail = raw;
  try { const j = raw ? JSON.parse(raw) : {}; detail = j.error || j.message || raw; } catch (_) {}
  return new Error(detail || fallback || ("HTTP " + r.status));
}

async function getProducts(){
  const r=await fetch(API+"/products");
  if(!r.ok) throw await readApiError(r,"API /products "+r.status);
  return r.json();
}
async function renderAll(silent=false){
 try{
  let ir=await fetch(API+"/inquiries");if(!ir.ok){let t=await ir.text();throw new Error("API /inquiries "+ir.status+": "+t)}let [ps,iq]=await Promise.all([getProducts(),ir.json()]);
  $("statProducts").textContent=ps.length;$("statImages").textContent=ps.reduce((n,p)=>n+(p.images?.length||0),0);$("statNew").textContent=iq.filter(x=>x.status==="New").length;$("inqCount").textContent=iq.filter(x=>x.status==="New").length;
  $("productList").innerHTML=ps.map(p=>`<div class="admin-product"><div class="admin-product-img">${p.images?.[0]?`<img src="${p.images[0]}">`:"⚙"}</div><div><b>${esc(p.name)}</b><small>${esc(p.cat||"")}</small><p>${esc(p.desc||"")}</p></div><div><button onclick="editProduct(${p.id})">Edit</button><button onclick="deleteProduct(${p.id})">Delete</button></div></div>`).join("")||"<p>No products yet.</p>";
  $("adminGallery").innerHTML=ps.flatMap(p=>(p.images||[]).map(img=>`<div class="gallery-item"><img src="${img}"><span>${esc(p.name)}</span></div>`)).join("")||"<div class='empty-gallery'>No pictures uploaded.</div>";
  $("inquiryList").innerHTML=iq.map(x=>`<div class="inquiry"><div><b>${esc(x.name)}</b><span>${esc(x.phone)} • ${esc(x.date||"")}</span><p>${esc(x.message)}</p></div><div><span class="status">${esc(x.status)}</span><button onclick="markReply(${x.id})">Mark Replied</button><button onclick="deleteInquiry(${x.id})">Delete</button></div></div>`).join("")||"<p>No customer inquiries yet.</p>";
 }catch(e){
   // Keep Admin Dashboard accessible while the D1/API binding is being configured.
   $("statProducts").textContent="—";
   $("statImages").textContent="—";
   $("statNew").textContent="—";
   $("productList").innerHTML="<p>API/D1 is not connected yet. Admin Login is working.</p>";
   $("adminGallery").innerHTML="<p>Connect the D1 API to load gallery data.</p>";
   $("inquiryList").innerHTML="<p>Connect the D1 API to load inquiries.</p>";
   if(!silent) console.warn(e);
 }
}
$("productForm").addEventListener("submit",async e=>{e.preventDefault();let fd=new FormData();fd.append("name",$("pname").value.trim());fd.append("cat",$("pcat").value.trim());fd.append("desc",$("pdesc").value.trim());fd.append("image_urls",JSON.stringify(selectedImages.map(x=>x.data)));let edit=$("editIndex").value;try{let r=await fetch(API+"/products"+(edit?"/"+edit:""),{method:edit?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:$("pname").value.trim(),cat:$("pcat").value.trim(),desc:$("pdesc").value.trim(),images:selectedImages.map(x=>x.data)})});if(!r.ok) throw await readApiError(r,"HTTP "+r.status);resetForm();await renderAll();alert("Product saved. Pictures are stored in Cloudinary.")}catch(err){console.error("Product save failed:",err);alert("Product save failed.\n\n"+(err?.message||"Check D1 API binding and schema."))}});
async function editProduct(id){let ps=await getProducts(),p=ps.find(x=>x.id==id);if(!p)return;$("editIndex").value=p.id;$("pname").value=p.name;$("pcat").value=p.cat||"";$("pdesc").value=p.desc||"";selectedImages=[];renderPreview();location.hash="products"}
async function deleteProduct(id){if(confirm("Delete this product and its Cloudinary pictures?")){let r=await fetch(API+"/products/"+id,{method:"DELETE"});if(r.ok)renderAll();else alert("Delete failed")}}
function resetForm(){$("editIndex").value="";$("pname").value="";$("pcat").value="";$("pdesc").value="";$("pimages").value="";selectedImages=[];$("preview").innerHTML=""}
async function markReply(id){await fetch(API+"/inquiries/"+id,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"Replied"})});renderAll()}
async function deleteInquiry(id){if(confirm("Delete inquiry?")){await fetch(API+"/inquiries/"+id,{method:"DELETE"});renderAll()}}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
showApp();
async function fillSocialProducts(){
 const sel=document.getElementById("socialProduct"); if(!sel)return;
 const ps=await getProducts();
 sel.innerHTML='<option value="">Select Product</option>'+ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
}
async function generateAllSocial(){
 const id=document.getElementById("socialProduct").value;
 if(!id){alert("Please select a product.");return}
 const ps=await getProducts(),p=ps.find(x=>String(x.id)===String(id));if(!p)return;
 const extra=document.getElementById("aiExtra").value.trim();
 const base=`SAAD Engineering presents ${p.name}. ${p.desc||""} ${extra}`.trim();
 const tags="#SAADEngineering #Engineering #Industrial #Machinery #Bangladesh #Quality #Precision";
 const data={
  Facebook:`🚀 ${p.name}\n\n${base}\n\n📞 +880 1628-915220\n💬 WhatsApp Inquiry available.\n\n${tags}`,
  YouTube:`${p.name} | SAAD Engineering\n\n${base}\n\nContact: +880 1628-915220\n\n${tags} #YouTube`,
  TikTok:`⚙️ ${p.name}\n${base}\n📲 WhatsApp: +880 1628-915220\n\n${tags} #TikTok #FYP`,
  LinkedIn:`SAAD Engineering | ${p.name}\n\n${base}\n\nFor product details and industrial solutions, contact our team.\n📞 +880 1628-915220\n\n${tags} #LinkedIn #Industry`,
  WhatsApp:`Hello! SAAD Engineering-এর ${p.name} সম্পর্কে জানতে চাই।\n\n${base}\n\nPlease share price, specification and availability.`,
  Instagram:`⚙️ ${p.name}\n\n${base}\n\n📲 DM / WhatsApp: +880 1628-915220\n\n${tags} #Instagram #Reels`,
  Telegram:`📢 SAAD Engineering — ${p.name}\n\n${base}\n\n📞 +880 1628-915220\n\n${tags} #Telegram`
 };
 document.getElementById("socialResults").innerHTML=Object.entries(data).map(([name,text])=>`
 <div class="social-box"><div class="social-title">${name}</div><textarea id="social-${name}" readonly>${esc(text)}</textarea>
 <div class="social-actions"><button onclick="copySocial('${name}')">Copy</button><button onclick='openSocial(${JSON.stringify(name)},${JSON.stringify(text)})'>Open</button></div></div>`).join("");
}
function copySocial(name){navigator.clipboard.writeText(document.getElementById("social-"+name).value).then(()=>alert(name+" content copied."))}
function openSocial(name,text){
 const urls={Facebook:"https://www.facebook.com/",YouTube:"https://studio.youtube.com/",TikTok:"https://www.tiktok.com/upload",LinkedIn:"https://www.linkedin.com/feed/",WhatsApp:"https://wa.me/8801628915220?text="+encodeURIComponent(text),Instagram:"https://www.instagram.com/",Telegram:"https://web.telegram.org/"};
 window.open(urls[name],"_blank");
}
const _oldRenderAll=renderAll;
renderAll=async function(){await _oldRenderAll();await fillSocialProducts()};
