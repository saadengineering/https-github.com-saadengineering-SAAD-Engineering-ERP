# SAAD Engineering ERP
Cloudflare Pages-ready standalone ERP/POS prototype.

Demo login: admin / admin123

Cloudflare Pages settings:
- Framework: None
- Build command: none
- Build output directory: web
- Root directory: /

The web/_redirects file is intentionally empty to prevent redirect loops.
